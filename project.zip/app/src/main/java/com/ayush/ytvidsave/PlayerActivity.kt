package com.ayush.ytvidsave

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.media.AudioManager
import android.os.Bundle
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.WindowManager
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private var volAcc = 0f

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = PlayerView(this)
        setContentView(view)
        val p = ExoPlayer.Builder(this).build()
        view.player = p
        val u = intent.data
        if (u != null) {
            p.setMediaItem(MediaItem.fromUri(u))
            p.prepare()
            p.playWhenReady = true
        }
        player = p
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || Math.abs(dy) < Math.abs(dx) || view.height == 0) return false
                if (e1.x < view.width / 2) {
                    val lp = window.attributes
                    val cur = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                    lp.screenBrightness = (cur + dy / view.height).coerceIn(0.02f, 1f)
                    window.attributes = lp
                } else {
                    val am = getSystemService(AUDIO_SERVICE) as AudioManager
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    volAcc += dy / view.height * max * 1.5f
                    val step = volAcc.toInt()
                    if (step != 0) {
                        val v = (am.getStreamVolume(AudioManager.STREAM_MUSIC) + step).coerceIn(0, max)
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        volAcc -= step
                    }
                }
                return true
            }
        })
        view.setOnTouchListener { _, e -> gd.onTouchEvent(e); false }
    }

    override fun onUserLeaveHint() {
        if (player?.isPlaying == true) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            } catch (_: Exception) {}
        }
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        view.useController = !inPip
    }

    override fun onStop() {
        super.onStop()
        if (!isInPictureInPictureMode) player?.pause()
    }

    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }
}
