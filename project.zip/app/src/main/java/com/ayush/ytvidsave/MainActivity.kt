package com.ayush.ytvidsave

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val ready = CountDownLatch(1)
    private val pool = Executors.newFixedThreadPool(3)

    private fun js(fn: String, vararg a: String) = runOnUiThread {
        web.evaluateJavascript("$fn(" + a.joinToString(",") { JSONObject.quote(it) } + ")", null)
    }

    private fun JSONObject.str(k: String) = if (isNull(k)) "" else optString(k)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) {
                if (intent?.action == Intent.ACTION_SEND) shared(intent) else checkClip()
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        Thread {
            try {
                YoutubeDL.getInstance().init(application)
                FFmpeg.getInstance().init(application)
                js("onEngine", updateEngine(false))
            } catch (e: Exception) {
                js("onError", "Engine error: " + e.message)
            }
            ready.countDown()
        }.start()
    }

    private fun updateEngine(nightly: Boolean): String {
        synchronized(this) {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(
                    application,
                    if (nightly) YoutubeDL.UpdateChannel.NIGHTLY else YoutubeDL.UpdateChannel.STABLE
                )
            } catch (_: Exception) {}
            return try { YoutubeDL.getInstance().version(application) ?: "" } catch (_: Exception) { "" }
        }
    }

    private fun <T> retrying(block: () -> T): T = try {
        block()
    } catch (e: Exception) {
        val m = e.message ?: ""
        if (m.contains("DRM", true) || m.contains("Unsupported URL", true)) throw e
        js("onMsg", "Engine auto-fix ho raha hai, ruko...")
        updateEngine(true)
        block()
    }

    private fun play(id: Int) {
        runOnUiThread {
            try {
                val mp = MediaPlayer.create(this, id)
                mp.setOnCompletionListener { it.release() }
                mp.start()
            } catch (_: Exception) {}
        }
    }

    private var lastClip = ""

    private fun clipText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip
        if (c == null || c.itemCount == 0) return ""
        return c.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
    }

    private fun checkClip() {
        val t = clipText()
        if (t.contains("http") && t != lastClip) {
            lastClip = t
            js("onClip", t)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::web.isInitialized) checkClip()
    }

    private fun shared(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT)?.let { js("onShared", it) }
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        shared(i)
    }

    private fun save(f: File, audio: Boolean) {
        val ext = f.extension.lowercase()
        val mime = if (audio) when (ext) { "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; else -> "audio/ogg" }
        else when (ext) { "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; else -> "video/webm" }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music/YT Vid Save" else "Movies/YT Vid Save")
        }
        val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(coll, cv) ?: throw Exception("Gallery save failed")
        contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
    }

    inner class Bridge {
        @JavascriptInterface
        fun sound(name: String) {
            if (name == "start") play(R.raw.snd_start) else if (name == "done") play(R.raw.snd_done)
        }

        @JavascriptInterface
        fun paste() {
            runOnUiThread { js("onPasted", clipText()) }
        }

        @JavascriptInterface
        fun fix() {
            pool.execute {
                try {
                    ready.await()
                    js("onMsg", "Engine update ho raha hai...")
                    js("onEngine", updateEngine(true))
                    js("onFixed")
                } catch (e: Exception) {
                    js("onError", "Update failed: " + e.message)
                }
            }
        }

        @JavascriptInterface
        fun info(url: String) {
            pool.execute {
                try {
                    ready.await()
                    val req = YoutubeDLRequest(url)
                    req.addOption("--dump-single-json")
                    req.addOption("--no-playlist")
                    req.addOption("--no-warnings")
                    val j = JSONObject(retrying { YoutubeDL.getInstance().execute(req).out })
                    val hs = sortedSetOf<Int>()
                    val fm = j.optJSONArray("formats") ?: JSONArray()
                    for (i in 0 until fm.length()) {
                        val f = fm.getJSONObject(i)
                        val h = f.optInt("height", 0)
                        if (h > 0 && f.str("vcodec") != "none") hs.add(h)
                    }
                    val o = JSONObject()
                        .put("title", j.str("title"))
                        .put("thumb", j.str("thumbnail"))
                        .put("duration", j.str("duration_string"))
                        .put("heights", JSONArray(hs.toList().reversed()))
                    js("onInfo", o.toString())
                } catch (e: Exception) {
                    js("onError", (e.message ?: "Failed").takeLast(300))
                }
            }
        }

        @JavascriptInterface
        fun start(json: String) {
            pool.execute {
                val o = JSONObject(json)
                val mode = o.getString("mode")
                val h = o.optInt("height", 0)
                val vf = o.optString("vfmt", "mp4")
                val af = o.optString("afmt", "mp3")
                val abr = o.optInt("abr", 320)
                val dir = File(cacheDir, "dl" + System.currentTimeMillis()).apply { mkdirs() }
                try {
                    ready.await()
                    val cap = if (h > 0) "[height<=$h]" else ""
                    val acap = if (abr < 320) "[abr<=$abr]" else ""
                    val req = YoutubeDLRequest(o.getString("url"))
                    req.addOption("--no-playlist")
                    req.addOption("--windows-filenames")
                    req.addOption("-N", "4")
                    req.addOption("-o", dir.absolutePath + "/%(title).80B.%(ext)s")
                    when (mode) {
                        "audio" -> {
                            req.addOption("-f", "ba$acap/ba/b")
                            req.addOption("-x")
                            req.addOption("--audio-format", af)
                            req.addOption("--audio-quality", "${abr}K")
                        }
                        "video" -> {
                            req.addOption("-f", "bv*$cap/b$cap")
                            if (vf == "mp4") req.addOption("-S", "res,ext:mp4:m4a")
                            req.addOption("--remux-video", vf)
                        }
                        else -> {
                            req.addOption("-f", "bv*$cap+ba$acap/bv*$cap+ba/b$cap")
                            if (vf == "mp4") req.addOption("-S", "res,ext:mp4:m4a")
                            req.addOption("--merge-output-format", vf)
                        }
                    }
                    retrying {
                        YoutubeDL.getInstance().execute(req, "job" + System.nanoTime()) { p, _, line ->
                            if (p >= 0) js("onProgress", p.toInt().toString(), line)
                        }
                    }
                    val f = dir.listFiles()!!
                        .filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                        .maxByOrNull { it.length() }!!
                    js("onProgress", "100", "Gallery me save ho raha hai...")
                    save(f, mode == "audio")
                    js("onDone", f.name)
                } catch (e: Exception) {
                    js("onError", (e.message ?: "Failed").takeLast(300))
                } finally {
                    dir.deleteRecursively()
                }
            }
        }
    }
}
