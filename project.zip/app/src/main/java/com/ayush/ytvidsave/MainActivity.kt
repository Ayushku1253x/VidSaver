package com.ayush.ytvidsave

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val ready = CountDownLatch(1)
    @Volatile private var cancelled = false
    @Volatile private var infoId = ""
    @Volatile private var jobId = ""
    private val pool = Executors.newFixedThreadPool(4)

    private fun js(fn: String, vararg a: String) = runOnUiThread {
        web.evaluateJavascript("$fn(" + a.joinToString(",") { JSONObject.quote(it) } + ")", null)
    }

    private fun JSONObject.str(k: String) = if (isNull(k)) "" else optString(k)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val fl = android.content.IntentFilter("com.ayush.ytvidsave.INSTALL")
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(instRx, fl, android.content.Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(instRx, fl)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) {
                if (intent?.action == Intent.ACTION_SEND) shared(intent) else checkClip()
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        Thread {
            try {
                YoutubeDL.getInstance().init(application)
                FFmpeg.getInstance().init(application)
                js("onEngine", try { YoutubeDL.getInstance().version(application) ?: "" } catch (_: Exception) { "" })
            } catch (e: Exception) {
                js("onError", "Engine error: " + e.message)
            }
            ready.countDown()
        }.start()
        Thread {
            try {
                ready.await()
                cacheDir.listFiles()?.filter { it.name.startsWith("dl") && System.currentTimeMillis() - it.lastModified() > 2L * 24 * 3600 * 1000 }?.forEach { it.deleteRecursively() }
                if (getSharedPreferences("yt", MODE_PRIVATE).getBoolean("au", true)) pool.execute { Thread.sleep(4000); checkAppUpdate() }
            } catch (_: Exception) {}
        }.start()
    }

    private val lock = java.util.concurrent.locks.ReentrantReadWriteLock()

    private fun <T> reading(b: () -> T): T {
        lock.readLock().lock()
        try { return b() } finally { lock.readLock().unlock() }
    }

    private fun updateEngine(nightly: Boolean): String {
        lock.writeLock().lock()
        try {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(
                    application,
                    if (nightly) YoutubeDL.UpdateChannel.NIGHTLY else YoutubeDL.UpdateChannel.STABLE
                )
            } catch (_: Exception) {}
            getSharedPreferences("yt", MODE_PRIVATE).edit().putLong("upd", System.currentTimeMillis()).apply()
            return try { YoutubeDL.getInstance().version(application) ?: "" } catch (_: Exception) { "" }
        } finally {
            lock.writeLock().unlock()
        }
    }

    private fun quickPreview(url: String) {
        try {
            if (!(url.contains("youtube.com") || url.contains("youtu.be"))) return
            val c = java.net.URL("https://www.youtube.com/oembed?format=json&url=" + java.net.URLEncoder.encode(url, "UTF-8")).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            js("onQuick", j.str("title"), j.str("thumbnail_url"), j.str("author_name"))
        } catch (_: Exception) {}
    }

    private fun thumbOf(j: JSONObject): String {
        val t = j.str("thumbnail")
        if (t.isNotEmpty()) return t
        val ts = j.optJSONArray("entries")?.optJSONObject(0)?.optJSONArray("thumbnails") ?: return ""
        return ts.optJSONObject(ts.length() - 1)?.str("url") ?: ""
    }

    private val active = java.util.concurrent.atomic.AtomicInteger(0)
    private val hnd = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var paused = false
    private val stopSvc = Runnable { if (active.get() == 0) stopService(Intent(this, DownloadService::class.java)) }

    private fun svcStart() {
        runOnUiThread {
            hnd.removeCallbacks(stopSvc)
            try { startForegroundService(Intent(this, DownloadService::class.java)) } catch (_: Exception) {}
        }
    }

    private fun svcStopLater() {
        runOnUiThread { hnd.postDelayed(stopSvc, 10000) }
    }

    private fun notifyProgress(p: Int, text: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            val n = android.app.Notification.Builder(this, "dl")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("YT Vid Save  " + p + "%")
                .setContentText(text.take(60))
                .setProgress(100, p, false)
                .setOngoing(true)
                .build()
            nm.notify(1, n)
        } catch (_: Exception) {}
    }

    private fun notifyDone(name: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            val n = android.app.Notification.Builder(this, "dl")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Download complete")
                .setContentText(name)
                .setAutoCancel(true)
                .build()
            nm.notify(2, n)
        } catch (_: Exception) {}
    }

    private fun vdir(): File = File(filesDir, "vault").apply { mkdirs() }

    private fun vaultList(): String {
        val a = JSONArray()
        (vdir().listFiles() ?: emptyArray<File>()).sortedBy { it.name }.forEach {
            a.put(JSONObject().put("n", it.name).put("s", it.length()))
        }
        return a.toString()
    }

    private val instRx = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context?, i: Intent?) {
            val st = i?.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1) ?: return
            if (st == android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION) {
                val conf = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (conf != null) {
                    conf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(conf)
                }
            } else if (st != android.content.pm.PackageInstaller.STATUS_SUCCESS) {
                js("onMsg", "Install nahi hua: " + (i.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""))
            }
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(instRx) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun installApk(url: String) {
        pool.execute {
            try {
                if (!packageManager.canRequestPackageInstalls()) {
                    runOnUiThread {
                        startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, android.net.Uri.parse("package:" + packageName)))
                    }
                    js("onMsg", "Install permission allow karein, phir wapas aakar Update dabayein")
                    return@execute
                }
                val f = File(cacheDir, "update.apk")
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.instanceFollowRedirects = true
                c.connectTimeout = 10000
                c.readTimeout = 20000
                val total = c.contentLength.toLong()
                var done = 0L
                var last = -1
                c.inputStream.use { i ->
                    f.outputStream().use { o ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) { last = p; js("onUpd", p.toString()) }
                            }
                        }
                    }
                }
                val pi = packageManager.packageInstaller
                val sid = pi.createSession(android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL))
                pi.openSession(sid).use { s ->
                    f.inputStream().use { i ->
                        s.openWrite("app", 0, f.length()).use { o ->
                            i.copyTo(o)
                            s.fsync(o)
                        }
                    }
                    val pend = android.app.PendingIntent.getBroadcast(
                        this, sid,
                        Intent("com.ayush.ytvidsave.INSTALL").setPackage(packageName),
                        android.app.PendingIntent.FLAG_MUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    s.commit(pend.intentSender)
                }
            } catch (e: Exception) {
                js("onMsg", "Update fail: " + (e.message ?: ""))
            }
        }
    }

    private fun checkAppUpdate(manual: Boolean = false) {
        try {
            val c = java.net.URL("https://api.github.com/repos/Ayushku1253x/VidSaver/releases/latest").openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val tag = j.str("tag_name")
            val n = tag.substringAfterLast('.').toIntOrNull() ?: return
            val cur = packageManager.getPackageInfo(packageName, 0).longVersionCode
            val assets = j.optJSONArray("assets")
            if (n > cur && assets != null && assets.length() > 0) js("onAppUpdate", tag, assets.getJSONObject(0).str("browser_download_url"))
            else if (manual) js("onMsg", "Aap latest version par ho")
        } catch (_: Exception) {
            if (manual) js("onMsg", "Update check fail hua (internet check karein)")
        }
    }

    private fun <T> retrying(block: () -> T): T = try {
        block()
    } catch (e: Exception) {
        if (cancelled) throw e
        val m = e.message ?: ""
        if (m.contains("DRM", true) || m.contains("Unsupported URL", true)) throw e
        val recent = System.currentTimeMillis() - getSharedPreferences("yt", MODE_PRIVATE).getLong("upd", 0L) < 30L * 60 * 1000
        val extractErr = listOf("Unable to extract", "nsig", "HTTP Error 403", "Sign in to confirm", "player response", "Requested format is not available", "Failed to extract").any { m.contains(it, true) }
        if (recent || !extractErr) throw e
        js("onMsg", "Engine auto-fix ho raha hai, ruko...")
        updateEngine(true)
        block()
    }

    private var lastClip = ""

    private fun clipText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip
        if (c == null || c.itemCount == 0) return ""
        return c.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
    }

    private fun checkClip() {
        val t = clipText()
        if (t.contains("http") && t != lastClip) {
            lastClip = t
            js("onClip", t)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::web.isInitialized) checkClip()
    }

    private fun shared(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT)?.let { js("onShared", it) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.onBack?window.onBack():false") { r ->
            if (r != "true") super.onBackPressed()
        }
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        shared(i)
    }

    private fun save(f: File, audio: Boolean): Pair<String, String> {
        val ext = f.extension.lowercase()
        val mime = if (audio) when (ext) {
            "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "aac" -> "audio/aac"
            "flac" -> "audio/flac"; "wav" -> "audio/x-wav"; else -> "audio/ogg"
        } else when (ext) {
            "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; "mov" -> "video/quicktime"; else -> "video/webm"
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music/YT Vid Save" else "Movies/YT Vid Save")
        }
        val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(coll, cv) ?: throw Exception("Gallery save failed")
        contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        return Pair(uri.toString(), mime)
    }

    inner class Bridge {
        @JavascriptInterface
        fun paste() {
            runOnUiThread { js("onPasted", clipText()) }
        }

        @JavascriptInterface
        fun cancel() {
            cancelled = true
            pool.execute {
                try { YoutubeDL.getInstance().destroyProcessById(jobId) } catch (_: Exception) {}
                try { YoutubeDL.getInstance().destroyProcessById(infoId) } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun open(u: String, m: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.setDataAndType(android.net.Uri.parse(u), m)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(i)
                } catch (_: Exception) { js("onMsg", "Koi player nahi mila") }
            }
        }

        @JavascriptInterface
        fun openUrl(u: String) {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u))) } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun keepOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun share(u: String, m: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = m
                    i.putExtra(Intent.EXTRA_STREAM, android.net.Uri.parse(u))
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "Share"))
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun isWifi(): Boolean {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            return c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
                c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
        }

        @JavascriptInterface
        fun checkUpdate() {
            pool.execute { checkAppUpdate(true) }
        }

        @JavascriptInterface
        fun appVer(): String {
            return try { packageManager.getPackageInfo(packageName, 0).longVersionCode.toString() } catch (_: Exception) { "1" }
        }

        @JavascriptInterface
        fun shareText(t: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_TEXT, t)
                    startActivity(Intent.createChooser(i, "Share"))
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun copy(t: String) {
            runOnUiThread {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("link", t))
            }
        }

        @JavascriptInterface
        fun notifPerm() {
            runOnUiThread {
                if (android.os.Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7)
            }
        }

        @JavascriptInterface
        fun pause() {
            paused = true
            cancel()
        }

        @JavascriptInterface
        fun play(u: String, m: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setDataAndType(android.net.Uri.parse(u), m))
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun isNight(): Boolean {
            val m = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
            return m == android.content.res.Configuration.UI_MODE_NIGHT_YES
        }

        @JavascriptInterface
        fun monet(): String {
            if (android.os.Build.VERSION.SDK_INT < 31) return ""
            return listOf(android.R.color.system_accent1_500, android.R.color.system_accent2_500, android.R.color.system_accent3_500)
                .joinToString(",") { String.format("#%06X", 0xFFFFFF and resources.getColor(it, theme)) }
        }

        @JavascriptInterface
        fun vaultAuth() {
            runOnUiThread {
                try {
                    val exec = mainExecutor
                    val b = android.hardware.biometrics.BiometricPrompt.Builder(this@MainActivity)
                        .setTitle("Private Vault")
                        .setSubtitle("Fingerprint / Face / PIN se unlock karein")
                    if (android.os.Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(255 or 32768)
                    else b.setNegativeButton("Cancel", exec) { _, _ -> js("onVaultFail") }
                    b.build().authenticate(android.os.CancellationSignal(), exec, object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                            js("onVault", vaultList())
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                            js("onVaultFail")
                        }
                    })
                } catch (_: Exception) { js("onVaultFail") }
            }
        }

        @JavascriptInterface
        fun vaultLock() {
            runOnUiThread { window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE) }
        }

        @JavascriptInterface
        fun vaultAdd(u: String, m: String, title: String) {
            pool.execute {
                try {
                    val ext = when {
                        m.contains("mpeg") -> "mp3"
                        m.contains("audio/mp4") -> "m4a"
                        m.contains("ogg") -> "ogg"
                        m.contains("aac") -> "aac"
                        m.contains("flac") -> "flac"
                        m.contains("wav") -> "wav"
                        m.contains("quicktime") -> "mov"
                        m.contains("matroska") -> "mkv"
                        m.contains("webm") -> "webm"
                        else -> "mp4"
                    }
                    val safe = title.replace(Regex("[^A-Za-z0-9 ._-]"), "_").take(70)
                    val f = File(vdir(), safe + "-" + (System.currentTimeMillis() % 100000) + "." + ext)
                    contentResolver.openInputStream(android.net.Uri.parse(u))!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    try { contentResolver.delete(android.net.Uri.parse(u), null, null) } catch (_: Exception) {}
                } catch (e: Exception) {
                    js("onMsg", "Vault me nahi daal paye: " + (e.message ?: ""))
                }
            }
        }

        @JavascriptInterface
        fun vaultPlay(name: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setData(android.net.Uri.fromFile(File(vdir(), name))))
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun vaultRestore(name: String) {
            pool.execute {
                try {
                    val f = File(vdir(), name)
                    val audio = listOf(".mp3", ".m4a", ".opus", ".ogg", ".aac", ".flac", ".wav").any { name.endsWith(it) }
                    save(f, audio)
                    f.delete()
                    js("onVault", vaultList())
                    js("onMsg", "Gallery me wapas aa gaya")
                } catch (e: Exception) {
                    js("onMsg", "Restore fail: " + (e.message ?: ""))
                }
            }
        }

        @JavascriptInterface
        fun vaultDelete(name: String) {
            pool.execute {
                File(vdir(), name).delete()
                js("onVault", vaultList())
            }
        }

        @JavascriptInterface
        fun installUpdate(url: String) {
            installApk(url)
        }

        @JavascriptInterface
        fun setAutoUpdate(on: Boolean) {
            getSharedPreferences("yt", MODE_PRIVATE).edit().putBoolean("au", on).apply()
        }

        @JavascriptInterface
        fun fix() {
            pool.execute {
                try {
                    ready.await()
                    js("onMsg", "Engine update ho raha hai...")
                    js("onEngine", updateEngine(true))
                    js("onFixed")
                } catch (e: Exception) {
                    js("onError", "Update failed: " + e.message)
                }
            }
        }

        @JavascriptInterface
        fun info(url: String, pl: Boolean) {
            pool.execute {
                try {
                    cancelled = false
                    infoId = "info" + System.nanoTime()
                    pool.execute { quickPreview(url) }
                    ready.await()
                    val req = YoutubeDLRequest(url)
                    req.addOption("--dump-single-json")
                    if (pl) { req.addOption("--yes-playlist"); req.addOption("--flat-playlist") } else req.addOption("--no-playlist")
                    req.addOption("--no-warnings")
                    req.addOption("--socket-timeout", "15")
                    req.addOption("--extractor-args", "youtube:skip=translated_subs")
                    val j = JSONObject(retrying { reading { YoutubeDL.getInstance().execute(req, infoId) { _, _, _ -> }.out } })
                    val dur = j.optDouble("duration", 0.0).let { if (it.isNaN()) 0.0 else it }
                    val hs = sortedSetOf<Int>()
                    val vs = JSONObject()
                    var abest = 0
                    val fm = j.optJSONArray("formats") ?: JSONArray()
                    for (i in 0 until fm.length()) {
                        val f = fm.getJSONObject(i)
                        val h = f.optInt("height", 0)
                        if (h > 0 && f.str("vcodec") != "none") {
                            hs.add(h)
                            var sz = f.optLong("filesize", 0L)
                            if (sz <= 0) sz = f.optLong("filesize_approx", 0L)
                            if (sz <= 0) sz = (f.optDouble("tbr", 0.0) * dur * 125).toLong()
                            if (sz > vs.optLong(h.toString(), 0L)) vs.put(h.toString(), sz)
                        } else if (f.str("vcodec") == "none" && f.str("acodec") != "none") {
                            abest = maxOf(abest, f.optDouble("abr", 0.0).toInt())
                        }
                    }
                    val o = JSONObject()
                        .put("title", j.str("title"))
                        .put("thumb", thumbOf(j))
                        .put("count", j.optJSONArray("entries")?.length() ?: 0)
                        .put("up", j.str("uploader"))
                        .put("views", j.optLong("view_count", 0L))
                        .put("duration", j.str("duration_string"))
                        .put("heights", JSONArray(hs.toList().reversed()))
                        .put("vsizes", vs)
                        .put("dur", dur)
                        .put("abest", abest)
                        .put("views", j.optLong("view_count", 0L))
                        .put("up", j.str("uploader"))
                        .put("date", j.str("upload_date"))
                    js("onInfo", o.toString())
                } catch (e: Exception) {
                    if (cancelled) js("onCancelled") else js("onError", (e.message ?: "Failed").takeLast(300))
                }
            }
        }

        @JavascriptInterface
        fun start(json: String) {
            pool.execute {
                val o = JSONObject(json)
                val mode = o.getString("mode")
                val h = o.optInt("height", 0)
                val vf = o.optString("vfmt", "mp4")
                val af = o.optString("afmt", "mp3")
                val abr = o.optInt("abr", 320)
                val dkey = Math.abs((o.getString("url") + mode + h + vf + af + abr + o.optString("clip", "") + o.optInt("pl", 0) + o.optInt("tpl", 1)).hashCode())
                val dir = File(cacheDir, "dl" + dkey).apply { mkdirs() }
                var keep = false
                active.incrementAndGet()
                svcStart()
                try {
                    cancelled = false
                    paused = false
                    jobId = "job" + System.nanoTime()
                    ready.await()
                    val cap = if (h > 0) "[height<=$h]" else ""
                    val acap = if (abr < 320) "[abr<=$abr]" else ""
                    val req = YoutubeDLRequest(o.getString("url"))
                    val pl = o.optInt("pl", 0) == 1
                    req.addOption(if (pl) "--yes-playlist" else "--no-playlist")
                    req.addOption("--windows-filenames")
                    req.addOption("--retries", "15")
                    req.addOption("--fragment-retries", "15")
                    req.addOption("--retry-sleep", "3")
                    req.addOption("--socket-timeout", "20")
                    req.addOption("-N", "8")
                    val rate = o.optString("rate", "")
                    if (rate.isNotEmpty()) req.addOption("-r", rate)
                    if (o.optInt("meta", 1) == 1 && !(mode == "audio" && af == "wav")) req.addOption("--embed-metadata")
                    if (o.optInt("subs", 0) == 1 && mode != "audio") {
                        req.addOption("--write-subs")
                        req.addOption("--write-auto-subs")
                        req.addOption("--sub-langs", "en.*,hi.*")
                        req.addOption("--embed-subs")
                    }
                    if (o.optInt("sb", 0) == 1) req.addOption("--sponsorblock-remove", "sponsor,selfpromo")
                    if (o.optInt("thumb", 0) == 1 && ((mode == "audio" && (af == "mp3" || af == "m4a")) || (mode != "audio" && (vf == "mp4" || vf == "mkv")))) req.addOption("--embed-thumbnail")
                    val pend = o.optInt("pend", 0)
                    if (pl && pend > 0) req.addOption("--playlist-end", pend.toString())
                    val clip = o.optString("clip", "")
                    if (clip.isNotEmpty()) req.addOption("--download-sections", "*" + clip)
                    var nm = when (o.optInt("tpl", 1)) {
                        2 -> "%(uploader).30B - %(title).60B"
                        3 -> "%(title).70B [%(height)sp]"
                        else -> "%(title).80B"
                    }
                    if (pl) nm = "%(playlist_index)s - " + nm
                    req.addOption("-o", dir.absolutePath + "/" + nm + ".%(ext)s")
                    when (mode) {
                        "audio" -> {
                            req.addOption("-f", "ba$acap/ba/b")
                            req.addOption("-x")
                            req.addOption("--audio-format", af)
                            req.addOption("--audio-quality", "${abr}K")
                        }
                        "video" -> {
                            req.addOption("-f", "bv*$cap/b$cap")
                            if (vf == "mp4") req.addOption("-S", "res,ext:mp4:m4a")
                            req.addOption("--remux-video", vf)
                        }
                        else -> {
                            req.addOption("-f", "bv*$cap+ba$acap/bv*$cap+ba/b$cap")
                            if (vf == "mp4") req.addOption("-S", "res,ext:mp4:m4a")
                            req.addOption("--merge-output-format", if (vf == "mov") "mp4" else vf)
                            if (vf == "mov") req.addOption("--remux-video", "mov")
                        }
                    }
                    var lastTick = 0L
                    retrying {
                        reading {
                            YoutubeDL.getInstance().execute(req, jobId) { p, eta, line ->
                                val now = System.currentTimeMillis()
                                if (p >= 0) {
                                    if (now - lastTick > 500) {
                                        lastTick = now
                                        js("onProgress", p.toInt().toString(), line, eta.toString())
                                        notifyProgress(p.toInt(), line)
                                    }
                                } else if (listOf("[Merger]", "[VideoRemuxer]", "[ExtractAudio]", "[EmbedThumbnail]", "[Metadata]", "[SponsorBlock]", "[ModifyChapters]").any { line.contains(it) }) {
                                    js("onStage", "Processing: ffmpeg se jod raha hai... (badi file me time lagta hai)")
                                }
                            }
                        }
                    }
                    val skip = listOf(".part", ".ytdl", ".vtt", ".srt", ".jpg", ".webp", ".png")
                    val fs = dir.listFiles()!!
                        .filter { f -> f.isFile && skip.none { f.name.endsWith(it) } }
                        .sortedBy { it.name }
                    if (fs.isEmpty()) throw Exception("Koi file nahi bani")
                    js("onProgress", "100", "Gallery me save ho raha hai...", "0")
                    var total = 0L
                    for (f in fs) {
                        val r = save(f, mode == "audio")
                        total += f.length()
                        js("onFile", f.name, f.length().toString(), r.first, r.second)
                    }
                    notifyDone(if (fs.size == 1) fs[0].name else fs.size.toString() + " files")
                    js("onDone", if (fs.size == 1) fs[0].name else fs.size.toString() + " files", total.toString())
                } catch (e: Exception) {
                    keep = true
                    if (paused) js("onPaused")
                    else if (cancelled) { keep = false; js("onCancelled") }
                    else js("onError", (e.message ?: "Failed").takeLast(300))
                } finally {
                    if (!keep) dir.deleteRecursively()
                    active.decrementAndGet()
                    svcStopLater()
                }
            }
        }
    }
}
