package com.ayush.ytvidsave

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val ready = CountDownLatch(1)
    @Volatile private var cancelled = false
    @Volatile private var infoId = ""
    @Volatile private var jobId = ""
    private val pool = Executors.newFixedThreadPool(4)

    private fun js(fn: String, vararg a: String) = runOnUiThread {
        web.evaluateJavascript("$fn(" + a.joinToString(",") { JSONObject.quote(it) } + ")", null)
    }

    private fun JSONObject.str(k: String) = if (isNull(k)) "" else optString(k)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) {
                if (intent?.action == Intent.ACTION_SEND) shared(intent) else checkClip()
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        Thread {
            try {
                YoutubeDL.getInstance().init(application)
                FFmpeg.getInstance().init(application)
                js("onEngine", try { YoutubeDL.getInstance().version(application) ?: "" } catch (_: Exception) { "" })
            } catch (e: Exception) {
                js("onError", "Engine error: " + e.message)
            }
            ready.countDown()
        }.start()
        Thread {
            try {
                ready.await()
                pool.execute { Thread.sleep(4000); checkAppUpdate() }
                Thread.sleep(12000)
                val sp = getSharedPreferences("yt", MODE_PRIVATE)
                if (System.currentTimeMillis() - sp.getLong("upd", 0L) > 12L * 3600 * 1000 && lock.writeLock().tryLock()) {
                    try { js("onEngine", updateEngine(false)) } finally { lock.writeLock().unlock() }
                }
            } catch (_: Exception) {}
        }.start()
    }

    private val lock = java.util.concurrent.locks.ReentrantReadWriteLock()

    private fun <T> reading(b: () -> T): T {
        lock.readLock().lock()
        try { return b() } finally { lock.readLock().unlock() }
    }

    private fun updateEngine(nightly: Boolean): String {
        lock.writeLock().lock()
        try {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(
                    application,
                    if (nightly) YoutubeDL.UpdateChannel.NIGHTLY else YoutubeDL.UpdateChannel.STABLE
                )
            } catch (_: Exception) {}
            getSharedPreferences("yt", MODE_PRIVATE).edit().putLong("upd", System.currentTimeMillis()).apply()
            return try { YoutubeDL.getInstance().version(application) ?: "" } catch (_: Exception) { "" }
        } finally {
            lock.writeLock().unlock()
        }
    }

    private fun quickPreview(url: String) {
        try {
            if (!(url.contains("youtube.com") || url.contains("youtu.be"))) return
            val c = java.net.URL("https://www.youtube.com/oembed?format=json&url=" + java.net.URLEncoder.encode(url, "UTF-8")).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            js("onQuick", j.str("title"), j.str("thumbnail_url"), j.str("author_name"))
        } catch (_: Exception) {}
    }

    private fun thumbOf(j: JSONObject): String {
        val t = j.str("thumbnail")
        if (t.isNotEmpty()) return t
        val ts = j.optJSONArray("entries")?.optJSONObject(0)?.optJSONArray("thumbnails") ?: return ""
        return ts.optJSONObject(ts.length() - 1)?.str("url") ?: ""
    }

    private fun checkAppUpdate(manual: Boolean = false) {
        try {
            val c = java.net.URL("https://api.github.com/repos/Ayushku1253x/VidSaver/releases/latest").openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val tag = j.str("tag_name")
            val n = tag.substringAfterLast('.').toIntOrNull() ?: return
            val cur = packageManager.getPackageInfo(packageName, 0).longVersionCode
            val assets = j.optJSONArray("assets")
            if (n > cur && assets != null && assets.length() > 0) js("onAppUpdate", tag, assets.getJSONObject(0).str("browser_download_url"))
            else if (manual) js("onMsg", "Aap latest version par ho")
        } catch (_: Exception) {
            if (manual) js("onMsg", "Update check fail hua (internet check karein)")
        }
    }

    private fun <T> retrying(block: () -> T): T = try {
        block()
    } catch (e: Exception) {
        if (cancelled) throw e
        val m = e.message ?: ""
        if (m.contains("DRM", true) || m.contains("Unsupported URL", true)) throw e
        js("onMsg", "Engine auto-fix ho raha hai, ruko...")
        updateEngine(true)
        block()
    }

    private var lastClip = ""

    private fun clipText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip
        if (c == null || c.itemCount == 0) return ""
        return c.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
    }

    private fun checkClip() {
        val t = clipText()
        if (t.contains("http") && t != lastClip) {
            lastClip = t
            js("onClip", t)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::web.isInitialized) checkClip()
    }

    private fun shared(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT)?.let { js("onShared", it) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.onBack?window.onBack():false") { r ->
            if (r != "true") super.onBackPressed()
        }
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        shared(i)
    }

    private fun save(f: File, audio: Boolean): Pair<String, String> {
        val ext = f.extension.lowercase()
        val mime = if (audio) when (ext) { "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; else -> "audio/ogg" }
        else when (ext) { "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; else -> "video/webm" }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music/YT Vid Save" else "Movies/YT Vid Save")
        }
        val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(coll, cv) ?: throw Exception("Gallery save failed")
        contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        return Pair(uri.toString(), mime)
    }

    inner class Bridge {
        @JavascriptInterface
        fun paste() {
            runOnUiThread { js("onPasted", clipText()) }
        }

        @JavascriptInterface
        fun cancel() {
            cancelled = true
            pool.execute {
                try { YoutubeDL.getInstance().destroyProcessById(jobId) } catch (_: Exception) {}
                try { YoutubeDL.getInstance().destroyProcessById(infoId) } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun open(u: String, m: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.setDataAndType(android.net.Uri.parse(u), m)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(i)
                } catch (_: Exception) { js("onMsg", "Koi player nahi mila") }
            }
        }

        @JavascriptInterface
        fun openUrl(u: String) {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u))) } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun keepOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun share(u: String, m: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = m
                    i.putExtra(Intent.EXTRA_STREAM, android.net.Uri.parse(u))
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "Share"))
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun isWifi(): Boolean {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            return c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
                c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
        }

        @JavascriptInterface
        fun checkUpdate() {
            pool.execute { checkAppUpdate(true) }
        }

        @JavascriptInterface
        fun appVer(): String {
            return try { packageManager.getPackageInfo(packageName, 0).longVersionCode.toString() } catch (_: Exception) { "1" }
        }

        @JavascriptInterface
        fun fix() {
            pool.execute {
                try {
                    ready.await()
                    js("onMsg", "Engine update ho raha hai...")
                    js("onEngine", updateEngine(true))
                    js("onFixed")
                } catch (e: Exception) {
                    js("onError", "Update failed: " + e.message)
                }
            }
        }

        @JavascriptInterface
        fun info(url: String, pl: Boolean) {
            pool.execute {
                try {
                    cancelled = false
                    infoId = "info" + System.nanoTime()
                    pool.execute { quickPreview(url) }
                    ready.await()
                    val req = YoutubeDLRequest(url)
                    req.addOption("--dump-single-json")
                    if (pl) { req.addOption("--yes-playlist"); req.addOption("--flat-playlist") } else req.addOption("--no-playlist")
                    req.addOption("--no-warnings")
                    req.addOption("--socket-timeout", "15")
                    req.addOption("--extractor-args", "youtube:skip=translated_subs")
                    val j = JSONObject(retrying { reading { YoutubeDL.getInstance().execute(req, infoId) { _, _, _ -> }.out } })
                    val dur = j.optDouble("duration", 0.0).let { if (it.isNaN()) 0.0 else it }
                    val hs = sortedSetOf<Int>()
                    val vs = JSONObject()
                    var abest = 0
                    val fm = j.optJSONArray("formats") ?: JSONArray()
                    for (i in 0 until fm.length()) {
                        val f = fm.getJSONObject(i)
                        val h = f.optInt("height", 0)
                        if (h > 0 && f.str("vcodec") != "none") {
                            hs.add(h)
                            var sz = f.optLong("filesize", 0L)
                            if (sz <= 0) sz = f.optLong("filesize_approx", 0L)
                            if (sz <= 0) sz = (f.optDouble("tbr", 0.0) * dur * 125).toLong()
                            if (sz > vs.optLong(h.toString(), 0L)) vs.put(h.toString(), sz)
                        } else if (f.str("vcodec") == "none" && f.str("acodec") != "none") {
                            abest = maxOf(abest, f.optDouble("abr", 0.0).toInt())
                        }
                    }
                    val o = JSONObject()
                        .put("title", j.str("title"))
                        .put("thumb", thumbOf(j))
                        .put("count", j.optJSONArray("entries")?.length() ?: 0)
                        .put("duration", j.str("duration_string"))
                        .put("heights", JSONArray(hs.toList().reversed()))
                        .put("vsizes", vs)
                        .put("dur", dur)
                        .put("abest", abest)
                        .put("views", j.optLong("view_count", 0L))
                        .put("up", j.str("uploader"))
                        .put("date", j.str("upload_date"))
                    js("onInfo", o.toString())
                } catch (e: Exception) {
                    if (cancelled) js("onCancelled") else js("onError", (e.message ?: "Failed").takeLast(300))
                }
            }
        }

        @JavascriptInterface
        fun start(json: String) {
            pool.execute {
                val o = JSONObject(json)
                val mode = o.getString("mode")
                val h = o.optInt("height", 0)
                val vf = o.optString("vfmt", "mp4")
                val af = o.optString("afmt", "mp3")
                val abr = o.optInt("abr", 320)
                val dir = File(cacheDir, "dl" + System.currentTimeMillis()).apply { mkdirs() }
                try {
                    cancelled = false
                    jobId = "job" + System.nanoTime()
                    ready.await()
                    val cap = if (h > 0) "[height<=$h]" else ""
                    val acap = if (abr < 320) "[abr<=$abr]" else ""
                    val req = YoutubeDLRequest(o.getString("url"))
                    val pl = o.optInt("pl", 0) == 1
                    req.addOption(if (pl) "--yes-playlist" else "--no-playlist")
                    req.addOption("--windows-filenames")
                    req.addOption("-N", "8")
                    val rate = o.optString("rate", "")
                    if (rate.isNotEmpty()) req.addOption("-r", rate)
                    if (o.optInt("meta", 1) == 1) req.addOption("--embed-metadata")
                    if (o.optInt("subs", 0) == 1 && mode != "audio") {
                        req.addOption("--write-subs")
                        req.addOption("--write-auto-subs")
                        req.addOption("--sub-langs", "en.*,hi.*")
                        req.addOption("--embed-subs")
                    }
                    if (o.optInt("sb", 0) == 1) req.addOption("--sponsorblock-remove", "sponsor,selfpromo")
                    if (o.optInt("thumb", 0) == 1 && vf != "webm" && af != "opus") req.addOption("--embed-thumbnail")
                    val pend = o.optInt("pend", 0)
                    if (pl && pend > 0) req.addOption("--playlist-end", pend.toString())
                    val clip = o.optString("clip", "")
                    if (clip.isNotEmpty()) req.addOption("--download-sections", "*" + clip)
                    var nm = when (o.optInt("tpl", 1)) {
                        2 -> "%(uploader).30B - %(title).60B"
                        3 -> "%(title).70B [%(height)sp]"
                        else -> "%(title).80B"
                    }
                    if (pl) nm = "%(playlist_index)s - " + nm
                    req.addOption("-o", dir.absolutePath + "/" + nm + ".%(ext)s")
                    when (mode) {
                        "audio" -> {
                            req.addOption("-f", "ba$acap/ba/b")
                            req.addOption("-x")
                            req.addOption("--audio-format", af)
                            req.addOption("--audio-quality", "${abr}K")
                        }
                        "video" -> {
                            req.addOption("-f", "bv*$cap/b$cap")
                            if (vf == "mp4") req.addOption("-S", "res,ext:mp4:m4a")
                            req.addOption("--remux-video", vf)
                        }
                        else -> {
                            req.addOption("-f", "bv*$cap+ba$acap/bv*$cap+ba/b$cap")
                            if (vf == "mp4") req.addOption("-S", "res,ext:mp4:m4a")
                            req.addOption("--merge-output-format", vf)
                        }
                    }
                    retrying {
                        reading {
                            YoutubeDL.getInstance().execute(req, jobId) { p, eta, line ->
                                if (p >= 0) js("onProgress", p.toInt().toString(), line, eta.toString())
                            }
                        }
                    }
                    val skip = listOf(".part", ".ytdl", ".vtt", ".srt", ".jpg", ".webp", ".png")
                    val fs = dir.listFiles()!!
                        .filter { f -> f.isFile && skip.none { f.name.endsWith(it) } }
                        .sortedBy { it.name }
                    if (fs.isEmpty()) throw Exception("Koi file nahi bani")
                    js("onProgress", "100", "Gallery me save ho raha hai...", "0")
                    var total = 0L
                    for (f in fs) {
                        val r = save(f, mode == "audio")
                        total += f.length()
                        js("onFile", f.name, f.length().toString(), r.first, r.second)
                    }
                    js("onDone", if (fs.size == 1) fs[0].name else fs.size.toString() + " files", total.toString())
                } catch (e: Exception) {
                    if (cancelled) js("onCancelled") else js("onError", (e.message ?: "Failed").takeLast(300))
                } finally {
                    dir.deleteRecursively()
                }
            }
        }
    }
}
